## Problema:
Burocracia e logística ruim para se realizar matrículas. 

## Contexto:
Em todo início de semestre, em vez dos próprios alunos se matricularem (ou algum sistema matrículá-los automaticamente), a "peteca" é repassada à alguns poucos funcionários, o que, obviamente, gera um enorme gargalo.
Além disso, é ruim também para o aluno, que há de se deslocar até a faculdade e esperar numa fila por longos períodos; impedindo, por exemplo, o mesmo de realizar alguma viagem durante o período de matrícula.

## Solução:
Matrícula WEB, site onde o aluno pode se matricular sozinho, de onde quiser, facilitando tanto a Universidade como o próprio discente. Dessa forma, a burocracia (no que tange a "matrículação") é ínfima, reduzida basicamente à questões excepcionais como, por exemplo, alunos que talvez se matricularam em matérias que não queriam etc.

## Público-Alvo:
Alunos e Universidade (sistema)